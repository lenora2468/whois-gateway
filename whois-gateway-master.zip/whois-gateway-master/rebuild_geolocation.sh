wget -O geolite.tar.gz "PASTE_PERSONAL_DOWNLOAD_URL_FOR_GEOLITE_CITY_GZIP"
tar -zxvf geolite.tar.gz
rm geolite.tar.gz
